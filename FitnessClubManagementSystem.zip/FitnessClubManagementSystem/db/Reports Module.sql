CREATE TABLE reports (
    report_id INT AUTO_INCREMENT PRIMARY KEY,
    report_type ENUM('Weight', 'Fee', 'Due Fees', 'Salary', 'Expense', 'Profit'),
    related_id INT,
    amount DECIMAL(10, 2),
    report_date DATE,
    FOREIGN KEY (related_id) REFERENCES customers(customer_id) ON DELETE CASCADE,
    FOREIGN KEY (related_id) REFERENCES instructors(instructor_id) ON DELETE CASCADE,
    FOREIGN KEY (related_id) REFERENCES equipment(equipment_id) ON DELETE CASCADE
);
