CREATE TABLE Payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT,
    amount DECIMAL(10, 2),
    payment_date DATE,
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id) ON DELETE CASCADE
);
CREATE TABLE Salaries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    instructor_id INT,
    amount DECIMAL(10, 2),
    salary_date DATE,
    FOREIGN KEY (instructor_id) REFERENCES instructors(instructor_id) ON DELETE CASCADE
);
CREATE TABLE DueFees (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT,
    amount DECIMAL(10, 2),
    due_date DATE,
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id) ON DELETE CASCADE
);
CREATE TABLE Rentals (
    rental_id INT AUTO_INCREMENT PRIMARY KEY,
    amount DECIMAL(10, 2),
    rental_date DATE
);
ALTER TABLE Rentals
ADD COLUMN equipment_id INT;

ALTER TABLE Rentals
ADD CONSTRAINT fk_equipment_id
FOREIGN KEY (equipment_id) REFERENCES Equipment(equipment_id)
ON DELETE CASCADE;



CREATE TABLE Equipment (
    equipment_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    price DECIMAL(10, 2)
);


