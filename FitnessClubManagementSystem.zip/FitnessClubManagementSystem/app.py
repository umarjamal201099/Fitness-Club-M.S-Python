from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_mysqldb import MySQL
import datetime 
import subprocess
import os

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Set a secret key for session management

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'root'
app.config['MYSQL_DB'] = 'umar'

mysql = MySQL(app)



@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Fetch user from database
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM users WHERE username = %s AND password = %s", (username, password))
        user = cur.fetchone()
        cur.close()

        if user:
            session['logged_in'] = True
            session['username'] = username
            # Login successful
            return redirect(url_for('dashboard'))
        else:
            # Incorrect username or password
            return render_template('login.html', error='Incorrect username or password')

    return render_template('login.html')


@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))


@app.route('/dashboard')
def dashboard():
    # Check if user is logged in, if not redirect to login page
    if 'logged_in' in session:
        return render_template('dashboard.html')
    else:
        return redirect(url_for('login'))
    

@app.route('/customer_registration', methods=['GET', 'POST'])
def customer_registration():
    # Fetch workouts from the database
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM workouts")
    workouts = cur.fetchall()
    cur.close()
    # Render the customer registration form and pass the workouts
    return render_template('customer_registration.html', workouts=workouts)
# Route to handle customer registration form submission
@app.route('/add_customer', methods=['POST'])
def add_customer():
    if request.method == 'POST':
        # Extract form data
        name = request.form['name']
        email = request.form['email']
        phone = request.form['phone']
        height = request.form['height']
        weight = request.form['weight']
        waist = request.form['waist']
        workout = request.form['workout']
        goal = request.form['goal']
        # Save data to the database
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO customers (name, email, phone, height, weight, waist, workout, goal) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)",
                    (name, email, phone, height, weight, waist, workout, goal))
        mysql.connection.commit()
        cur.close()
        # Redirect to confirmation page
        return redirect(url_for('customer_registration_confirmation'))
    else:
        # Handle GET request if needed
        pass
    return redirect(url_for('customer_registration_confirmation'))
@app.route('/customers')
def view_customers():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM customers")
    customers = cur.fetchall()
    cur.close()
    return render_template('view_customers.html', customers=customers)
@app.route('/customer_registration_confirmation')
def customer_registration_confirmation():
    return render_template('customer_registration_confirmation.html')
@app.route('/edit_customer/<int:customer_id>', methods=['GET', 'POST'])
def edit_customer(customer_id):
    if request.method == 'GET':
        # Fetch customer data from the database
        cursor = mysql.connection.cursor()
        cursor.execute("SELECT * FROM customers WHERE customer_id = %s", (customer_id,))
        customer = cursor.fetchone()  # Fetch a single row
        cursor.close()

        # Render the edit_customer.html template with customer data
        return render_template('edit_customer.html', customer=customer)
    
    elif request.method == 'POST':
        # Get form data from the request
        name = request.form['name']
        email = request.form['email']
        phone = request.form['phone']
        height = request.form['height']
        weight = request.form['weight']
        waist = request.form['waist']
        workout = request.form['workout']
        goal = request.form['goal']

        # Update customer data in the database
        with mysql.connection.cursor() as cursor:
            cursor.execute("UPDATE customers SET name=%s, email=%s, phone=%s, height=%s, weight=%s, waist=%s, workout=%s, goal=%s WHERE customer_id=%s", (name, email, phone, height, weight, waist, workout, goal, customer_id))
            mysql.connection.commit()
            cursor.close()
        # Redirect to the edit_customer_confirmation route after updating
        return redirect(url_for('edit_customer_confirmation'))
    # Render the edit_customer form with pre-filled data
    return render_template('edit_customer.html', customer=customer)

@app.route('/edit_customer_confirmation', methods=['GET'])
def edit_customer_confirmation():
    return render_template('edit_customer_confirmation.html')
# Route to delete an customer
@app.route('/delete_customer/<int:customer_id>', methods=['POST'])
def delete_customer(customer_id):
    cur = mysql.connection.cursor()
    cur.execute("DELETE FROM customers WHERE customer_id = %s", (customer_id,))
    mysql.connection.commit()
    cur.close()
    return redirect(url_for('view_customers'))



# Route to handle GET requests for instructor registration form
@app.route('/instructor_registration', methods=['GET'])
def show_instructor_registration_form():
    # Render the instructor registration form template
    return render_template('instructor_registration_form.html')

# Route to handle POST requests for instructor registration form submission
@app.route('/register_instructor', methods=['POST'])
def register_instructor():
        # Get form data
    name = request.form['name']
    email = request.form['email']
    qualification = request.form['qualification']
    timings = request.form['timings']
    phone = request.form['phone']

    # Connect to MySQL and insert data into the database
    cur = mysql.connection.cursor()
    cur.execute("INSERT INTO instructors (name, email, qualification, timings, phone) VALUES (%s, %s, %s, %s, %s)", (name, email, qualification, timings, phone))
    mysql.connection.commit()
    cur.close()
    # After processing, you can redirect to a confirmation page
    return redirect(url_for('instructor_registration_confirmation'))

# Route to display instructor registration confirmation page
@app.route('/instructor_registration_confirmation')
def instructor_registration_confirmation():
    return render_template('instructor_registration_confirmation.html')

@app.route('/instructors')
def view_instructors():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM instructors")
    instructors = cur.fetchall()
    cur.close()
    return render_template('view_instructors.html', instructors=instructors)
@app.route('/edit_instructor/<int:instructor_id>', methods=['GET', 'POST'])
def edit_instructor(instructor_id):
    if request.method == 'GET':
        # Fetch instructor data from the database
        cursor = mysql.connection.cursor()
        cursor.execute("SELECT * FROM instructors WHERE instructor_id = %s", (instructor_id,))
        instructor = cursor.fetchone()  # Fetch a single row
        cursor.close()

        # Render the edit_instructor.html template with instructor data
        return render_template('edit_instructor.html', instructor=instructor)
    
    elif request.method == 'POST':
        # Get form data from the request
        name = request.form['name']
        email = request.form['email']
        phone = request.form['phone']
        qualification = request.form['qualification']
        timings = request.form['timings']

        # Update instructor data in the database
        with mysql.connection.cursor() as cursor:
            cursor.execute("UPDATE instructors SET name=%s, email=%s, phone=%s, qualification=%s, timings=%s WHERE instructor_id=%s", (name, email, phone, qualification, timings, instructor_id))
            mysql.connection.commit()
        # Redirect to the edit_instructor_confirmation route after updating
        return redirect(url_for('edit_instructor_confirmation'))
    
    # Handle other HTTP methods if needed
    return redirect(url_for('dashboard'))

@app.route('/edit_instructor_confirmation', methods=['GET'])
def edit_instructor_confirmation():
    return render_template('edit_instructor_confirmation.html')
# Route to delete an instructor
@app.route('/delete_instructor/<int:instructor_id>', methods=['POST'])
def delete_instructor(instructor_id):
    cur = mysql.connection.cursor()
    cur.execute("DELETE FROM instructors WHERE instructor_id = %s", (instructor_id,))
    mysql.connection.commit()
    cur.close()
    return redirect(url_for('view_instructors'))

# Route for rendering the workout management page
@app.route('/workout_management')
def workout_management():
    cur = mysql.connection.cursor()
    
    # Fetch existing workouts from database
    cur.execute("SELECT * FROM workouts")
    workouts = cur.fetchall()
    
    # Fetch existing Customers from database
    cur.execute("SELECT * FROM customers")
    customers = cur.fetchall()

    # Fetch categories from the workout_categories table
    cur.execute("SELECT category_id, category_name FROM workout_categories")
    categories = cur.fetchall()
    
    # Execute the join query
    cur.execute(
        "SELECT workouts.Name AS workout_name, workout_categories.category_name, workouts.workout_id "
        "FROM workouts "
        "JOIN workout_categories ON workouts.category_id = workout_categories.category_id;"
    )
     # Fetch all the results
    query_results = cur.fetchall()

    # Close the cursor and connection
    cur.close()
    
    # Pass both workouts and categories to the template
    return render_template('workout_management.html', workouts=workouts, customers=customers, categories=categories, query_results=query_results)

# Route for adding a new workout
@app.route('/add_workout', methods=['POST'])
def add_workout():
    if request.method == 'POST':
        workout_name = request.form['workout_name']
        category = request.form['category']
        
        cur = mysql.connection.cursor()

        # Insert new workout into database
        sql = "INSERT INTO workouts (name, category_id) VALUES (%s, %s)"
        val = (workout_name, category)
        cur.execute(sql, val)
        mysql.connection.commit()
        cur.close()
        flash('Workout added successfully!', 'success')
        return redirect(url_for('workout_management'))

# Route for deleting a workout
@app.route('/delete_workout/<int:workout_id>', methods=['POST'])
def delete_workout(workout_id):
    cur = mysql.connection.cursor()
    # Delete the workout record from the database
    cur.execute("DELETE FROM workouts WHERE workout_id = %s", (workout_id,))
    mysql.connection.commit()
    cur.close()
    flash('Workout deleted successfully!', 'success')
    return redirect(url_for('workout_management'))
@app.route('/edit_workout/<int:workout_id>', methods=['GET', 'POST'])
def edit_workout(workout_id):
    if request.method == 'POST':
        try:
            # Get updated workout details from the form
            workout_name = request.form['workout_name']
            category = request.form['category']
            
            cur = mysql.connection.cursor()
            # Update the workout record in the database
            cur.execute("UPDATE workouts SET name = %s, category_id = %s WHERE workout_id = %s", (workout_name, category, workout_id))
            mysql.connection.commit()
            flash('Workout updated successfully', 'success')  # Flash success message
            # Redirect to the workout management page after editing
            return redirect('/workout_management')  # Redirect to the workout management page
        except Exception as e:
            # Handle the error here
            flash('An error occurred while updating the workout', 'error')
            return redirect(request.url)  # Redirect back to the same page to display the error message

    else:
        try:
            cur = mysql.connection.cursor()
            # Fetch the workout details from the database
            cur.execute("SELECT name, category_id FROM workouts WHERE workout_id = %s", (workout_id,))
            workout = cur.fetchone()
            
            # Fetch categories from the workout_categories table
            cur.execute("SELECT category_id, category_name FROM workout_categories")
            categories = cur.fetchall()
            
            return render_template('edit_workout.html', workout=workout, categories=categories, workout_id=workout_id)
        except Exception as e:
            # Handle the error here
            flash('An error occurred while fetching the workout details', 'error')
            return redirect('/workout_management')  # Redirect to the workout management page if an error occurs during fetching
        
# Route for assigning a workout to a customer
@app.route('/assign_workout', methods=['POST'])
def assign_workout():
    if request.method == 'POST':
        customer_id = request.form['customer_name']
        workout_id = request.form['workout_select']
        cur = mysql.connection.cursor()
        cur.execute('INSERT INTO Customer_Workout_plans (customer_id, workout_id) VALUES (%s, %s)', (customer_id, workout_id))
        mysql.connection.commit()
        cur.close()
        flash('Workout assigned to customer successfully!', 'success')
        return redirect(url_for('workout_management'))
  
    


@app.route('/accounts')
def accounts():
    # Fetch and display payments, salaries, rentals, and due fees
    payments = get_payments_from_database()  # Fetch payments from the database
    salaries = get_salaries_from_database()  # Fetch salaries from the database
    rentals = get_rentals_from_database()    # Fetch rentals from the database
    due_fees = get_due_fees_from_database()  # Fetch due fees from the database
    return render_template('accounts.html', payments=payments, salaries=salaries, rentals=rentals, due_fees=due_fees)

@app.route('/add_payment', methods=['POST'])
def add_payment():
     # Retrieve data from the form
    customer_id = request.form['customer_id']
    amount = request.form['amount']
    payment_date = request.form['payment_date']
    
    cur = mysql.connection.cursor()
    cur.execute('INSERT INTO Payments (customer_id, amount, payment_date) VALUES (%s, %s, %s)',(customer_id, amount, payment_date))
    mysql.connection.commit()
    cur.close()
    flash('Added the Customer payment successfully!', 'success')
    return redirect('/accounts')

@app.route('/add_salary', methods=['POST'])
def add_salary():
    # Get form data
    employee_id = request.form['employee_id']
    salary_amount = request.form['salary_amount']
    salary_date = request.form['salary_date']
    
    cur = mysql.connection.cursor()
    cur.execute('INSERT INTO Salaries (instructor_id, amount, salary_date) VALUES (%s, %s, %s)',(employee_id, salary_amount, salary_date))
    mysql.connection.commit()
    cur.close()
    
    flash('Added the Salary payment successfully!', 'success')
    return redirect('/accounts')


@app.route('/add_rental', methods=['POST'])
def add_rental():
    # Get form data
    equipment_id = request.form['equipment_id']
    rental_amount = request.form['rental_amount']
    rental_date = request.form['rental_date']
        
    cur = mysql.connection.cursor()
    cur.execute('INSERT INTO Rentals (equipment_id, amount, rental_date) VALUES (%s, %s, %s)',(equipment_id, rental_amount, rental_date))
    mysql.connection.commit()
    cur.close()
    
    flash('Added the Rental payment successfully!', 'success')
    return redirect('/accounts')

@app.route('/add_due_fee', methods=['POST'])
def add_due_fee():
     # Extract data from the form submission
    customer_id = request.form['customer_id']
    amount = request.form['amount']
    due_date = request.form['due_date']
    
    cur = mysql.connection.cursor()
    cur.execute('INSERT INTO DueFees (customer_id, amount, due_date) VALUES (%s, %s, %s)',(customer_id, amount, due_date))
    mysql.connection.commit()
    cur.close()
    
    flash('Added the Due Fee successfully!', 'success')
    return redirect('/accounts')


# Functions to fetch data from the database
def get_payments_from_database():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM Payments")
    payments = cur.fetchall()
    return payments

def get_salaries_from_database():
    # Fetch salaries from the database
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM Salaries")
    salaries = cur.fetchall()
    return salaries

def get_rentals_from_database():
    # Fetch rentals from the database
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM Rentals")
    rentals = cur.fetchall()
    return rentals

def get_due_fees_from_database():
    # Fetch due fees from the database
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM DueFees")
    due_fees = cur.fetchall()
    return due_fees


@app.route('/generated_reports')
def generated_reports():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM reports")
    allreports = cur.fetchall()
    cur.close()
    return render_template('generated_reports.html', allreports=allreports)

@app.route('/reports', methods=['GET'])
def show_reports():
    selected_report_type = None
    allreports = None

    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM reports")
    allreports = cur.fetchall()
    cur.close()

    return render_template('reports.html', allreports=allreports, selected_report_type=selected_report_type)

@app.route('/reports', methods=['POST'])
def generate_report_post():
    selected_report_type = None
    reports = None
    allreports = None

    report_type = request.form['report_type']
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM reports WHERE report_type = %s", (report_type,))
    reports = cur.fetchall()
    cur.close()
    selected_report_type = report_type

    return render_template('reports.html', reports=reports, selected_report_type=selected_report_type)

@app.route('/generate_report', methods=['POST'])
def generate_report():
    report_type = request.form['report_type']
    cur = mysql.connection.cursor()

    if report_type == 'Weight':
        # Fetch weight data from customers table
        cur.execute("SELECT name, weight FROM customers")
        weight_data = cur.fetchall()
        reports = [{'report_type': 'Weight', 'data': f"{row[0]}: {row[1]}", 'report_date': datetime.now()} for row in weight_data]

    elif report_type == 'Fee':
        # Fetch fee data from payments table
        cur.execute("SELECT customer_id, amount FROM payments")
        fee_data = cur.fetchall()
        reports = [{'report_type': 'Fee', 'data': f"Customer ID: {row[0]}, Amount: {row[1]}", 'report_date': datetime.now()} for row in fee_data]

    elif report_type == 'Due Fees':
        # Fetch due fee data from duefees table
        cur.execute("SELECT customer_id, amount FROM duefees")
        due_fee_data = cur.fetchall()
        reports = [{'report_type': 'Due Fees', 'data': f"Customer ID: {row[0]}, Amount: {row[1]}", 'report_date': datetime.now()} for row in due_fee_data]

    elif report_type == 'Salary':
        # Fetch salary data from salaries table
        cur.execute("SELECT instructor_id, amount FROM salaries")
        salary_data = cur.fetchall()
        reports = [{'report_type': 'Salary', 'data': f"Instructor ID: {row[0]}, Amount: {row[1]}", 'report_date': datetime.now()} for row in salary_data]

    elif report_type == 'Expense':
        # Fetch expense data from expenses table (assuming you have an expenses table)
        cur.execute("SELECT expense_id, amount FROM expenses")
        expense_data = cur.fetchall()
        reports = [{'report_type': 'Expense', 'data': f"Expense ID: {row[0]}, Amount: {row[1]}", 'report_date': datetime.now()} for row in expense_data]

    elif report_type == 'Profit':
       # Calculate profit by subtracting expenses from total revenue (assuming you have an expenses table)
        cur.execute("SELECT SUM(amount) FROM payments")
        total_revenue = cur.fetchone()[0] or 0  # Use 0 if total_revenue is None
        cur.execute("SELECT SUM(amount) FROM expenses")
        total_expenses = cur.fetchone()[0] or 0  # Use 0 if total_expenses is None
        profit = total_revenue - total_expenses
        reports = [{'report_type': 'Profit', 'data': f"Profit: {profit}", 'report_date': datetime.now()}]
    else:
        reports = []

    # Insert reports into the reports table
    for report in reports:
        cur.execute("INSERT INTO reports (report_type, data, report_date) VALUES (%s, %s, %s)", (report['report_type'], report['data'], report['report_date']))
        mysql.connection.commit()
    cur.close()
    flash('Report generated successfully', 'success')
    return redirect('/reports')

# Define the path to the MySQL bin directory
mysql_bin_path = r'C:\Program Files\MySQL\MySQL Server 8.0\bin'

@app.route('/backup', methods=['GET', 'POST'])
def backup():
    if request.method == 'POST':
        try:
            backup_folder = 'C:/FitnessClubManagementSystem/Backup'  # Specify the full path to the backup folder
            if not os.path.exists(backup_folder):
                os.makedirs(backup_folder)
            
            current_time = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            backup_file = f"{backup_folder}/backup_{current_time}.sql"

            # Replace placeholders with actual MySQL credentials and database name
            username = 'root'
            password = 'your_password'  # Update with your MySQL password
            dbname = 'umar'

            # Execute mysqldump command to create a backup including data
            subprocess.run([f'{mysql_bin_path}/mysqldump', '-u', username, '-p' + password, dbname, '>', backup_file], shell=True)

            return render_template('backup.html', backup_success=True, message=f"Backup created successfully. Filename: {backup_file}")
        except Exception as e:
            print(e)  # Print the error for debugging
            return render_template('backup.html', backup_success=False, message=f"Failed to create backup: {str(e)}")
    else:
        return render_template('backup.html', backup_success=False, message="")


if __name__ == '__main__':
    app.run(debug=True)
